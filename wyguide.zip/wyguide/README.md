# wyguide

This is our final project for CS50, which takes the idea of Harvard's Q-guide that allows students to rate a class and a professor, and 
applies it to our high school.


A lot of the baseline code in main.py and helpers.py came from pset7 (Finance Stock Trading site) of CS50.
